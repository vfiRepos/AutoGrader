from pydantic_formating import SkillReport
from openai import OpenAI
import os
from dotenv import load_dotenv
import asyncio
import time
import json

# Load environment variables
load_dotenv()
client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))

INSTRUCTIONS = """
You are an SVP in equipment finance grading a sales call transcript for **Value Proposition Communication**.

Instructions:
- Did the rep clearly articulate VFI's value proposition?
- Did they explain the benefits of equipment financing vs. alternatives?
- Did they highlight VFI's competitive advantages?
- Did they address the prospect's specific needs and pain points?

IMPORTANT: You must respond with ONLY a JSON object in this exact format:
{{
  "items": [
    {{
      "skill": "value_prop",
      "grade": "A",
      "reasoning": "Your detailed reasoning here"
    }}
  ]
}}

Do not include any other text, explanations, or formatting outside the JSON.

Transcript: 
{transcript}
"""

async def VFIValue_grader_agent(transcript: str):
    start_time = time.time()
    print("🔄 Starting Value Proposition Grading...")
    
    prompt = INSTRUCTIONS.format(transcript=transcript)
    response = client.chat.completions.create(
        model="gpt-4o-mini",
        messages=[{"role": "user", "content": prompt}]
    )
    
    # Debug: Print what the AI actually returned
    ai_response = response.choices[0].message.content
    print(f"🤖 AI Response: {ai_response[:200]}...")
    
    try:
        result = SkillReport.model_validate_json(ai_response)
    except Exception as e:
        print(f"❌ JSON parsing failed: {e}")
        print(f"🔍 Raw response: {ai_response}")
        # Create a fallback result
        result = SkillReport.model_validate({
            "items": [
                {
                    "skill": "value_prop",
                    "grade": "C",
                    "reasoning": "Error parsing AI response"
                }
            ]
        })
    
    elapsed = time.time() - start_time
    print(f"✅ Value Proposition Grading completed in {elapsed:.2f}s")
    return result