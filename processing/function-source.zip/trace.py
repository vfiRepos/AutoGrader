from pydantic_formating import SkillReport
import json
from datetime import datetime

def trace_result(category: str, transcript: str, result: SkillReport):
    trace_entry = {
        "timestamp": datetime.utcnow().isoformat(),
        "category": category,
        "transcript_excerpt": transcript[:200],  # avoid logging full transcript if huge
        "grade": result.items[0].grade,
        "reasoning": result.items[0].reasoning,
    }
    with open("grading_trace.jsonl", "a") as f:
        f.write(json.dumps(trace_entry) + "\n")
